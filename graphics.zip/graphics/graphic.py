import math
from PIL import Image as i

v = 0.5
colormass = [(127, 127, 127), (12, 206, 15), (134, 111, 48), (84, 13, 146), (244, 4, 27), (201, 27, 93)]
color = colormass[4]
cs_color = (0, 0, 0)
ppi = 0.0001
mm = 3.793627
sq = 40 * mm  # расстояние между делениями на коорд. плоскости
source =f"C:\\Users\\pokys\\OneDrive\\Pictures\\horiz.png"#r'C:\Users\pokys\OneDrive\Pictures\horiz.png'
photo = i.open(f'{source}')
(width, height) = photo.size
print(str(width) + 'x' + str(height))
obj = photo.load()

x0 = width / 2
y0 = height / 2


def photo_saving():
    photo.save(f"C:\\Users\\pokys\\OneDrive\\Pictures\\project.jpg")


def photo_showing():
    photo.show()


def starting(name):
    print(f'{name.__name__}: Starting...')


def success(name):
    print(f'{name.__name__}: Success!')


def photo_clear():
    starting(photo_clear)
    # отбеливание картинки:
    a = 0
    while a <= width - 1:
        g = 0
        while g <= height - 1:
            # m = obj[a, g]
            obj[a, g] = (255, 255, 255)

            g += 1
        a += 1
    success(photo_clear)


def coord_sys():
    starting(coord_sys)
    # отрисовка системы координат
    # y:
    y = y0
    while y <= height - 1:
        obj[x0, y] = cs_color

        y += 1

    y = y0
    while y >= 0:
        obj[x0, y] = cs_color

        y -= 1

    # x:

    x = x0
    while x <= width - 1:
        obj[x, y0] = cs_color
        x += 1

    x = x0
    while x >= 0:
        obj[x, y0] = cs_color
        x -= 1

    # расстановка обозначений на оси
    # x:
    x = x0 + sq
    while x < width - 1:
        y = y0 - 2
        while y <= y0 + 2:
            obj[x, y] = cs_color

            y += 1
        x += sq - v

    x = x0 - sq
    while x > 0:
        y = y0 - 2
        while y <= y0 + 2:
            obj[x, y] = cs_color
            y += 1
        x -= sq - v

    # y:

    y = y0 + sq
    while y < height - 1:
        x = x0 - 2
        while x < x0 + 2:
            obj[x, y] = cs_color
            x += 1

        y += sq - v

    y = y0 - sq
    while y > 0:
        x = x0 - 2
        while x <= x0 + 2:
            obj[x, y] = cs_color
            x += 1

        y -= sq - v
    success(coord_sys)


def func():
    starting(func)
    a = x0 / sq
    x = 0

    while a <= 2 * x0 / sq:
        try:
            y = 1 /(1 + math.exp(-x))
            g = -sq * float(y) + y0
            if g >= 3:
                if g <= height:
                    obj[-sq * a, g] = color
        except ValueError:
            pass
        except ZeroDivisionError:
            pass

        x -= ppi
        a += ppi

    a = x0 / sq
    x = 0

    while a >= 0:
        try:
            y = 1 /(1 + math.exp(-x))
            g = -sq * float(y) + y0
            if g >= 0:
                if g <= height:
                    obj[-sq * a, g] = color
        except ValueError:
            pass
        except ZeroDivisionError:
            pass
        x += ppi
        a -= ppi
    success(func)
